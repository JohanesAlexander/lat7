import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_RED = "\u001B[31m";


    Scanner scanInt = new Scanner(System.in);
    Scanner scanStr = new Scanner(System.in);

    ArrayList<CAnimal> animalList = new ArrayList<>();
    //ArrayList<char [][] >map = new ArrayList<char[][]>();

    int size =7;

    char [][] map = new char[size][size];

    public void initializeEmptyMap(){
        for(int i=0;i<size;i++){
            for(int j=0;j<size;j++){
                map[j][i]='.';
            }
        }
    }


    public void printMap(){
        for(int i=0;i<size;i++){
            //System.out.println("");
            for(int j=0;j<size;j++){
                System.out.print("| "+ map[i][j] + " ");
            }
            System.out.println("|");
        }
    }

    public void printColorMap(int index){

        int x=index/10;
        int y=index-(x*10);
        for(int i=0;i<size;i++){
            //System.out.println("");
            for(int j=0;j<size;j++){
                if (i==y && j==x){
                    System.out.print("| "+ANSI_RED + map[i][j] +ANSI_RESET+ " ");
                }
                else{
                    System.out.print("| "+ map[i][j] + " ");
                }

            }
            System.out.println("|");
        }


    }

    public void printAnimal(){
        for (int i = 0; i < animalList.size(); i++) {
            if (animalList.get(i) instanceof CCow) {
                System.out.println((i + 1) + ".Sapi umur " + animalList.get(i).getUmur());
            } else if(animalList.get(i) instanceof CChicken){
                System.out.println((i+1) + ".Ayam umur " + animalList.get(i).getUmur());
            }
        }
    }



    public void addAnimalMenu(){

        System.out.println("1.Sapi\n" +
                "2.Ayam\n" +
                "3.Cancel");
        int resp =-1;

        while(resp!=3){
            resp = scanInt.nextInt();
            if (resp ==1){
                addCow();
            }
            else if(resp==2){
                addChicken();
            }
        }
        //Main();
    }

    public void addCow(){
        int successAdd=0;
        int x;
        int y;
        int twoDigit;
        while(successAdd!=1){
            System.out.println("enter x  and y value for map: \n" +
                    "enter it as 2 digit for example 13 mean x=1 and y=3\n" +
                    "below are the map for available space\n");
            printMap();
            twoDigit = scanInt.nextInt();
            System.out.println(twoDigit);
            x=twoDigit/10;
            y=twoDigit-(x*10);


            if (map[y][x]=='.'){
                System.out.println("enter age for your cow: ");
                int age = scanInt.nextInt();
                CCow mySapi = new CCow(x,y,"sapi",age);
                animalList.add(mySapi);
                map[x][y] = 'S';
                printColorMap(twoDigit);
                System.out.println("cow successfully added");
                successAdd++;
                //Main();
                break;

            }
            else{
                System.out.println("This place is already occupied by another animal");
            }
        }
    }


    public void addChicken(){
        int successAdd=0;
        int x;
        int y;
        int twoDigit;
        while(successAdd!=1){
            System.out.println("enter x  and y value for map: \n" +
                    "enter it as 2 digit for example 13 mean x=1 and y=3\n" +
                    "below are the map for available space\n");
            printMap();
            twoDigit = scanInt.nextInt();
            x=twoDigit/10;
            y=twoDigit-(x*10);
            if (map[y][x]=='.'){
                System.out.println("enter age for your chicken: ");
                int weight = scanInt.nextInt();
                CCow myAyam = new CCow(x,y,"ayam",weight);
                animalList.add(myAyam);
                map[x][y] = 'A';
                printColorMap(twoDigit);
                System.out.println("chicken successfully added");
                successAdd=1;
                //Main();
            }
            else{
                System.out.println("This place is already occupied by another animal");
            }
        }
    }


    public void changeDays(){
        int jmlSapi=0;

        System.out.println("adding 3 days to all of our animals");

        for (int i = 0; i<animalList.size() ; i++) {
            animalList.get(i).setUmur(animalList.get(i).getUmur()+3);
            if (animalList.get(i) instanceof CCow){
                jmlSapi++;
            }
        }
        addWeight();
        addMilk(jmlSapi);

    }

    public void addMilk(int jmlSapi){
        CCow.setJmlTotalSusuSapi(CCow.getJmlTotalSusuSapi()+jmlSapi * 1);
    }

    public void addWeight(){
        for (int i = 0; i < animalList.size(); i++) {
            if (animalList.get(i) instanceof CChicken){
                float weight = ((CChicken) animalList.get(i)).getWeight();
                ((CChicken) animalList.get(i)).setWeight((float) (weight+0.2));
            }
        }
    }

    public int checkMilk(){
        int jmlMilk=0;
        jmlMilk = CAnimal.getJmlTotalSusuSapi();
        return jmlMilk;
    }

    public int checkChicken(){
        int jmlChicken=0;
        for (int i = 0; i < animalList.size(); i++) {

            if (animalList.get(i) instanceof CChicken) {
                if (((CChicken) animalList.get(i)).getWeight() > 5) {
                    jmlChicken += 1;
                }
            }// outer if
        }//end for
        return jmlChicken;
    }

    public int collectMilk(){
        int jmlMilk=0;
        jmlMilk = CAnimal.getJmlTotalSusuSapi();
        CAnimal.setJmlTotalSusuSapi(0);
        return jmlMilk;
    }

    public int collectChicken(){

        int jmlAyam=0;
        for (int i = 0; i < animalList.size(); i++) {

            if (animalList.get(i) instanceof CChicken) {
                if (((CChicken) animalList.get(i)).getWeight() > 5) {

                    int twoDigit = searchByAList(i);
                    int x=twoDigit/10;
                    int y=twoDigit-(x*10);

                    //int x=twoDigit/10;
                    //y=twoDigit-(x*10);


                    animalList.remove(i);
                    map[y][x] = '.';

                    jmlAyam += 1;
                }
            }// outer if
        }//end for

        return jmlAyam;
    }//end collect chicken


    public int searchByAList(int index){
        int xy;
        int x = animalList.get(index).getX() * 10;
        int y = animalList.get(index).getY();

        xy=x+y;

        return xy;
    }

    public int searchByARR(int xy){
        int x=xy/10;
        int y=xy-(x*10);
        int ind = 0;

        for (int i=0;i<animalList.size();i++){
            if (animalList.get(i).getX() == x && animalList.get(i).getY()==y){
                ind = i;
                break;
            }
        }
        return ind;

    }

    public void collectMenu(){
        int ayam=0;
        int susu=0;
        ayam = checkChicken();
        susu = checkMilk();
        System.out.println("Mengecek hewan ternak");


        if(ayam >0 && susu <=0){
            System.out.println("Ayam bisa dipanen: " + ayam + " ekor");
            confirmPanen(1,ayam);
        }

        else if(ayam <=0 && susu >= 0 ){
            System.out.println("Susu bisa dipanen: " + susu + "liter");
            confirmPanen(2,susu);
        }

        else if(ayam >=0 && susu >=0){
            System.out.println("ayam dan susu siap dipanen");
            System.out.println("Ayam: " + ayam + " ekor");
            System.out.println("Susu: " + susu + "liter");
            confirmPanen(3, ayam, susu);
        }

        else if (ayam <= 0 && susu <= 0){
            System.out.println("Tidak ada yang bisa dipanen");
        }

        //Main();

    }

    public void confirmPanen(int tipePanen, int jumlahApapun){
        int resp;
        System.out.println("konfirmasi panen? 1 utk iya 0 utk cancel");
        resp = scanInt.nextInt();

        while (resp==1){

            if (tipePanen==1){
                collectMilk();
                System.out.println("berhasil panen ayam sebanyak"+jumlahApapun);
            }

            else if(tipePanen==2){
                collectChicken();
                System.out.println("berhasil panen susu sebanyak"+jumlahApapun);

            }
        }
    }

    public void confirmPanen(int tipePanen, int jumlahAyam, int jumlahSusu){
        int resp;
        System.out.println("konfirmasi panen? 1 utk iya 0 utk cancel");
        resp = scanInt.nextInt();

        while (resp==3){
            if (tipePanen==1){
                collectMilk();
                System.out.println("berhasil panen ayam: " +jumlahAyam +" susu: "+ jumlahSusu);
            }
        }
    }

    public int checkKandangKosong(){
        int lokasi=0;

        for (int y=0;y<size;y++){
            for (int x=0;x<size;x++){
                if (map[y][x]=='.'){
                    lokasi = (x*10)+y;
                }
            }
        }

        return lokasi;
    }




    public void mainMenu(){

        System.out.println("0.exit\n" +
                            "1.Input hewan\n" +
                            "2.Cetak hewan\n" +
                            "3.Cetak map\n" +
                            "4.Ganti hari di peternakan (seluruh hewan)\n" +
                            "5.Cek/panen hewan ternak\n" +
                            "");
    }




    public Main() {

        if(map[0][0]==0){
            initializeEmptyMap();
        }

        int menu =-1;
        mainMenu();
        menu=scanInt.nextInt();

        while (menu!=0){

            if (menu==1){
                //printMap();
                addAnimalMenu();
            }
            else if(menu==2){
                printAnimal();
            }
            else if(menu ==3){
                printMap();
            }
            else if(menu==4){
                changeDays();
            }
            else if(menu==5){
                collectMenu();
            }
        }
    }

    public static void main(String[]args){

        Main myFarm = new Main();
    }
}
